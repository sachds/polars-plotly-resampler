"""AbstractAggregator interface-class, subclassed by concrete aggregators."""

from __future__ import annotations

__author__ = "Jonas Van Der Donckt"

import re
from abc import ABC, abstractmethod
from typing import List, Optional, Tuple
import polars as pl
import numpy as np
import datetime


class AbstractAggregator(ABC):
    DEFAULT_DTYPE_REGEX_LIST = [r'(?i)float\d*', r'(?i)int\d*', r'(?i)uint\d*', r'(?i)category', r'(?i)bool', r'(?i)utf8', r'(?i)datetime.*', 'Utf8', 'Float64', 'Int64']



    def __init__(
        self,
        x_dtype_regex_list: Optional[List[str]] = None,
        y_dtype_regex_list: Optional[List[str]] = None,
        **downsample_kwargs,
    ):
        """Constructor of AbstractSeriesAggregator.

        Parameters
        ----------
        x_dtype_regex_list: List[str], optional
            List containing the regex matching the supported datatypes for the x array,
            by default None.
        y_dtype_regex_list: List[str], optional
            List containing the regex matching the supported datatypes for the y array,
            by default None.
        downsample_kwargs: dict
            Additional kwargs passed to the downsample method.

        """
        self.x_dtype_regex_list = x_dtype_regex_list if x_dtype_regex_list is not None else self.DEFAULT_DTYPE_REGEX_LIST
        self.y_dtype_regex_list = self.DEFAULT_DTYPE_REGEX_LIST

        self.downsample_kwargs = downsample_kwargs

    @staticmethod
    def _check_n_out(n_out: int) -> None:
        """Check if the n_out is valid."""
        assert isinstance(n_out, (int, np.integer))
        assert n_out > 0

    @staticmethod
    def _process_args(*args) -> Tuple[np.ndarray | None, np.ndarray]:
        """Process the args into the x and y arrays.

        If only y is passed, x is set to None.
        """
        assert len(args) in [1, 2], "Must pass either 1 or 2 arrays"
        x, y = (None, args[0]) if len(args) == 1 else args
        return x, y

    @staticmethod
    def _check_arr(arr: pl.Series | np.ndarray, regex_list: Optional[List[str]] = None):
        """Check if the array/Series is valid."""

        # Log the type and values of the input array
        print(f"Inside _check_arr: Type of 'arr': {type(arr)}, first 10 values: {arr[:10]}")

        # Check if arr is a numpy ndarray or a Polars Series
        if isinstance(arr, np.ndarray):
            assert arr.ndim == 1, "Expected 1-dimensional array"
            dtype = arr.dtype
        elif isinstance(arr, pl.Series):
            assert len(arr.shape) == 1, "Expected 1-dimensional Series"
            dtype = arr.dtype
        else:
            raise ValueError(f"Expected np.ndarray or pl.Series, got {type(arr)}")

        print(f"Inside _check_arr: Detected dtype of 'arr': {dtype}")
        AbstractAggregator._supports_dtype(dtype, regex_list)

    def _check_x_y(self, x: pl.Series | np.ndarray | None, y: pl.Series | np.ndarray) -> None:
        """Check if the x and y arrays/Series are valid."""

        # Log the type and values of the input arrays
        if x is not None:
            print(f"Inside _check_x_y: Type of 'x': {type(x)}, first 10 values of x: {x[:10]}")
            print(f"Inside _check_x_y: Type of 'y': {type(y)}, first 10 values of y: {y[:10]}")

        # Convert numpy arrays to polars Series for uniform handling
        if isinstance(x, np.ndarray):
            x = pl.Series("x", x)
        if isinstance(y, np.ndarray):
            y = pl.Series("y", y)

        # Check x (if not None)
        if x is not None:
            self._check_arr(x, self.x_dtype_regex_list)
            assert len(x) == len(y), "x and y must have the same length"

        # Check y
        print(f"y dtype before check: {y.dtype}")
        self._check_arr(y, self.y_dtype_regex_list)



    @staticmethod
    def _supports_dtype(dtype, dtype_regex_list: Optional[List[str]] = None):
        # Debug Statements
        print(f"Dtype type: {type(dtype)}")
        if hasattr(dtype, "__str__"):
            print(f"Dtype as string: {str(dtype)}")

            
        if isinstance(dtype, pl.datatypes.classes.DataTypeClass):
            print("Dtype is recognized as a Polars DataTypeClass. Exiting early.")
            return

        # Check for 'Int64'
        if dtype == 'Int64':
            print("Dtype is 'Int64'. Exiting early.")
            return

        # If dtype_regex_list is None, then we're allowing all dtypes
        if dtype_regex_list is None:
            return

        dtype_str = str(dtype)  # Convert dtype to its string representation

        # Check if the dtype is in the rust_dtypes list
        for dtype_regex_str in dtype_regex_list:
            if re.match(dtype_regex_str, dtype_str):
                return

        raise ValueError(f"{dtype_str} doesn't match with any regex in {dtype_regex_list}")






class DataAggregator(AbstractAggregator, ABC):
    """Implementation of the AbstractAggregator interface for data aggregation.

    DataAggregator differs from DataPointSelector in that it doesn't select data points,
    but rather aggregates the data (e.g., mean).
    As such, the `_aggregate` method is responsible for aggregating the data, and thus
    returns a tuple of the aggregated x and y values.

    Concrete implementations of this class must implement the `_aggregate` method, and
    have full responsibility on how they deal with other high-frequency properties, such
    as `hovertext`, `marker_size`, 'marker_color`, etc ...
    """

    @abstractmethod
    def _aggregate(
        self,
        x: np.ndarray | None,
        y: np.ndarray,
        n_out: int,
    ) -> Tuple[np.ndarray, np.ndarray]:
        raise NotImplementedError

    def aggregate(
        self,
        *args,
        n_out: int,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Aggregate the data.

        Parameters
        ----------
        x, y: np.ndarray
            The x and y data of the to-be-aggregated series.
            The x array is optional (i.e., if only 1 array is passed, it is assumed to
            be the y array).
            The array(s) must be 1-dimensional, and have the same length (if x is
            passed).
            These cannot be passed as keyword arguments, as they are positional-only.
        n_out: int
            The number of samples which the downsampled series should contain.
            This should be passed as a keyword argument.

        Returns
        -------
        Tuple[np.ndarray, np.ndarray]
            The aggregated x and y data, respectively.

        """
        # Check n_out
        assert n_out is not None

        # Get x and y
        x, y = DataPointSelector._process_args(*args)

        # Check x and y
        self._check_x_y(x, y)

        return self._aggregate(x=x, y=y, n_out=n_out)


class DataPointSelector(AbstractAggregator, ABC):
    """Implementation of the AbstractAggregator interface for data point selection.

    DataPointSelector differs from DataAggregator in that they don't aggregate the data
    (e.g., mean) but instead select data points (e.g., first, last, min, max, etc ...).
    As such, the `_arg_downsample` method returns the index positions of the selected
    data points.

    This class utilizes the `arg_downsample` method to compute the index positions.
    """

    @abstractmethod
    def _arg_downsample(
        self,
        x: np.ndarray | None,
        y: np.ndarray,
        n_out: int,
    ) -> pl.Series :
        # Note: this method can utilize the self.downsample_kwargs property
        raise NotImplementedError

    def arg_downsample(
        self,
        *args,
        n_out: int,
    ) -> pl.Series:
        """Compute the index positions for the downsampled representation.

        Parameters
        ----------
        x, y: np.ndarray
            The x and y data of the to-be-aggregated series.
            The x array is optional (i.e., if only 1 array is passed, it is assumed to
            be the y array).
            The array(s) must be 1-dimensional, and have the same length (if x is
            passed).
            These cannot be passed as keyword arguments, as they are positional-only.
        n_out: int
            The number of samples which the downsampled series should contain.
            This should be passed as a keyword argument.

        Returns
        -------
        np.ndarray
            The index positions of the selected data points.

        """
        # Check n_out
        DataPointSelector._check_n_out(n_out)

        # Get x and y
        x, y = DataPointSelector._process_args(*args)

        # Convert potential numpy arrays to polars Series
        if isinstance(y, np.ndarray):
            y = pl.Series(y)
        if x is not None and isinstance(x, np.ndarray):
            x = pl.Series(x)

        # Check x and y
        self._check_x_y(x, y)

        if len(y) <= n_out:
            # Fewer samples than n_out -> return all indices
            return pl.arange(len(y))

        # More samples that n_out -> perform data aggregation
        return self._arg_downsample(x=x, y=y, n_out=n_out)
