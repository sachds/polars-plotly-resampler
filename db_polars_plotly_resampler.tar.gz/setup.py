from setuptools import setup, find_packages

setup(
    name='polars_plotly_resampler',
    version='0.1.0',
    packages=find_packages(),
    # install_requires=[
    #     # add your dependencies here
    #     # 'numpy',
    #     # 'pandas',
    #     # ...
    # ],
    author='Sachin Seth',
    # author_email='you@example.com',
    # description='A brief description of your library',
    license='MIT',
    # keywords='your keywords',
    # url='https://github.com/yourusername/polars_plotly_resampler',
)
